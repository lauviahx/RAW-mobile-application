//
//  SingleListingView.swift
//  RAW App
//
//  Created by Donata Lesiak on 02/05/2021.
//

import SwiftUI

struct SingleListingView: View {
    
    let listings: [Listing]
    
    var body: some View {
        Text("Single listing would be here")
        Image(listings[listing].image)
    }
}

//struct SingleListingView_Previews: PreviewProvider {
//    static var previews: some View {
//        SingleListingView()
//    }
//}
