//
//  ContentView.swift
//  RAW
//
//  Created by Donata Lesiak on 20/03/2021.
//

import SwiftUI


struct ContentView: View {
    
    @State var selected = 2 // Load 2 tag tab when application loads
    init() {
        UITabBar.appearance().barTintColor = UIColor(Color("Background")) // change the background colour of the tab bar to match design
        UITabBar.appearance().unselectedItemTintColor = UIColor(Color("PrimaryDark")) // set colour of unselected icons in tab bar
    }
    
    var body: some View {
        
        
        //Tab bar
        TabView(selection: $selected){
            
            SocialView()
                .tabItem {
                    Image("social")
                        .renderingMode(.template) //clearing the original colour of the icon and replacing it with init parameters/accent
                    Text("Social")
                }.tag(0)
            
            ListingsView()
                .tabItem {
                    Image("listing")
                        .renderingMode(.template)
                    Text("Listings")
                }.tag(1)
            
            DiscoverView()
                .tabItem {
                    Image("discover")
                        .renderingMode(.template)
                    Text("Discover")
                }.tag(2)
            
            MessagesView()
                .tabItem {
                    Image("chat")
                        .renderingMode(.template)
                    Text("Messages")
                }.tag(3)
            
            ProfileView()
                .tabItem {
                    Image("profile")
                        .renderingMode(.template)
                    Text("Profile")
                }.tag(4)
            
        }.accentColor(Color("Primary")) // set accent colour (selected tab view)
    }
}


struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
