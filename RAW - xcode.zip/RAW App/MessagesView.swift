//
//  MessagesView.swift
//  RAW
//
//  Created by Donata Lesiak on 20/03/2021.
//

import SwiftUI

struct MessagesView: View {
    var body: some View {
        
        NavigationView
        {
            ZStack{
                Color("Background").ignoresSafeArea()
                VStack
                {
                    
                    Text("No messages to display!")
                        .font(.footnote)
                        .foregroundColor(Color("GraySecondary400"))
                    
                }.padding(16)
            
            } .navigationBarColor(backgroundColor:(UIColor(Color(.white))), tintColor: (UIColor(Color("PrimaryDark")))) // navigation bar colour using UIKit - see navigation view
            .navigationBarTitle(Text("Messages"), displayMode: .automatic) //navigation bar
            .navigationBarItems( trailing:
                                    HStack {
                                        Button(action: {}) {
                                            Image("connections")
                                        }
                                    })
        }
    }
}

struct MessagesView_Previews: PreviewProvider {
    static var previews: some View {
        MessagesView()
    }
}
