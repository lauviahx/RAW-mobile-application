//
//  ListingsView.swift
//  RAW
//
//  Created by Donata Lesiak on 20/03/2021.
//

import SwiftUI

struct ListingsView: View {
    
    @State var listings = [
        Listing(id:0, image:"joanna-avatar", name:"Joanna", age:"18", date:"18/02/21", textShort:"Hi, any photographer around Bristol who want to shoot cosplay?", interested: ["mariusz-avatar","emily"], textMain: "Hi, any photographer around Bristol who want to shoot cosplay?", location: "Bristol, England",shootstyles: ["Beauty","Fashion","Lifestyle","Portrait","Promotional"], gender: "Male, including transgender men", experience: "Intermediate or above"),
        Listing(id:1, image:"kate-avatar", name:"Kate", age:"19", date:"05/02/21", textShort:"Hi all, I want to add some lingerie/topless shoots to my portfolio. Looking for experienced photograp...", interested: ["lisa-avatar"],textMain: "Hi all, I want to add some lingerie/topless shoots to my portfolio. Looking for experienced photographer who can guide me and make me feel comfortable!", location: "Bristol, England",shootstyles: ["Topless", "Lingerie"], gender: "Male only", experience: "Proficient or above"),
        Listing(id:2, image:"megan-avatar", name:"Megan", age:"10", date:"01/02/21", textShort:"Hello! I’m going to be in Bristol for a week from 17th Feb, happy to organise some shoots when...", interested: ["emily","lisa-avatar","kieran-avatar"],textMain: "Hello! I’m going to be in Bristol for a week from 17th Feb, happy to organise some shoots for when I’m there.", location: "Bristol, England",shootstyles: ["Beauty","Fashion","Lifestyle","Portrait","Promotional"], gender: "Open to all", experience: "Proficient or above"),
        Listing(id:3, image:"lucy-avatar", name:"Lucy", age:"21", date:"18/01/21", textShort:"Morning! I have an idea for cool shoot, need someone to help me make it happen!", interested: ["emily"],textMain: "Morning! I have an idea for cool shoot, need someone to help me make it happen!", location: "-",shootstyles: ["Lifestyle","Portrait","Promotional"], gender: "Open to all", experience: "Proficient or above"),
        Listing(id:4, image:"sofia-avatar-1", name:"Sofia", age:"18", date:"17/01/21", textShort:"Hello, want to try some studio shoots, let me know if youre interested!", interested: ["mariusz-avatar","sofia-avatar"],textMain: "Hello, want to try some studio shoots, let me know if youre interested!", location: "Bristol, England",shootstyles: ["Beauty","Fashion","Lifestyle","Portrait","Promotional"], gender: "Open to all", experience: "Competent or above"),
        Listing(id:5, image:"leah-avatar", name:"Leah", age:"28", date:"06/01/21", textShort:"Hi, anyone up for remote photoshoot?", interested: ["sofia-avatar","malcolm-avatar"],textMain: "Hi, anyone up for remote photoshoot?", location: "Any/Remote",shootstyles: ["Beauty","Lifestyle","Portrait"], gender: "Open to all", experience: "Open to all")
    ]
    
    @State private var selectedStateIndexListings = 0 // picker selector
    
    var body: some View {
        NavigationView{
            ScrollView{
                VStack(spacing: 10){
                    
                    Picker("Picker listings", selection: $selectedStateIndexListings, content: { //selection picker listings
                        Text("All listings")
                            .foregroundColor(Color("PrimaryDark"))
                            .fontWeight(.medium).tag(0)
                        
                        Text("Your listings").foregroundColor(Color("PrimaryDark"))
                            .fontWeight(.medium).tag(1)
                    })
                    .pickerStyle(SegmentedPickerStyle())
                    .padding(.bottom, 10)
                    
                    switch selectedStateIndexListings{
                    
                    case 0: //all listings
                        
                        ForEach(listings, id:\.self, content: { listing in
                            NavigationLink(destination: SingleListingView(singleListing: listing) // on click navigate to single listing view and pass data along (know which one was selected)
                            ){
                                VStack(alignment: .leading){
                                    HStack(alignment: .center){
                                        Image(listing.image)
                                            .resizable()
                                            .scaledToFill()
                                            .padding(EdgeInsets(top: 10, leading: 0, bottom: 0, trailing: 0))
                                            .frame(width: 49.0, height: 49.0)
                                            .clipShape(Circle())
                                        
                                        VStack(alignment: .leading){
                                            
                                            Text(listing.name + ", " + listing.age)
                                                .font(.callout)
                                                .fontWeight(.medium)
                                                .foregroundColor(Color("PrimaryDark"))
                                                .padding(.bottom, 1.0)
                                            
                                            Text(listing.date)
                                                .font(.caption2)
                                                .foregroundColor(Color("GraySecondary400"))
                                                .padding(.bottom, 1.0)
                                        }
                                        Spacer()
                                    }
                                    
                                    Text(listing.textShort)
                                        .font(.footnote)
                                        .foregroundColor(Color("GraySecondary400"))
                                        .allowsTightening(true)
                                        .minimumScaleFactor(0.75)
                                    
                                    Divider()
                                    
                                    HStack{
                                        ForEach(listing.interested, id:\.self, content: { person in
                                            
                                            Image(person)
                                                .resizable()
                                                .scaledToFill()
                                                .padding(EdgeInsets(top: 0, leading: 0, bottom: 0, trailing: 0))
                                                .frame(width: 20.0, height: 20.0)
                                                .clipShape(Circle())
                                            
                                        })
                                    }
                                }
                                
                                .padding()
                                .background(Color(.white))
                                .cornerRadius(5)
                                .shadow(color: Color("Shadow"), radius: 5)
                                
                            }
                        })
                        
                    default: //your listings
                        VStack{
                        Text("Nothing to display. Add your first listing now!")  // adding new data not implemented
                            .font(.footnote)
                            .foregroundColor(Color("GraySecondary400"))
                        }
                    }
                    
                }.padding(16)

            }
            .background(Color("Background"))
            .navigationBarColor(backgroundColor:(UIColor(Color(.white))), tintColor: (UIColor(Color("PrimaryDark")))) // navigation bar colour using UIKit - see navigation view
            .navigationBarTitle(Text("Listings")) //navigation bar
            .navigationBarItems( trailing:
                                    HStack {
                                        Button(action: {}) {
                                            Image("plus")
                                                .font(.largeTitle)
                                            
                                        }
                                    })
        }
        
    }
}


struct Listing: Identifiable, Hashable{
    var id: Int
    var image, name, age, date, textShort: String
    var interested: [String]
    var textMain, location: String
    var shootstyles: [String]
    var gender, experience: String
}


struct SingleListingView: View { // single view listing takes data from selected card
    
    let singleListing: Listing
    
    let columns = [
        GridItem(.adaptive(minimum: 100, maximum: 160),spacing: 0)
    ]
    
    var body: some View {
        
        ScrollView {
            VStack(alignment: .leading){
                VStack(alignment: .trailing){

                    Text(singleListing.date)
                        .font(.system(size: 11))
                        .foregroundColor(Color("GraySecondary400"))
                        .padding()
                    VStack(alignment: .center){
                        Image(singleListing.image)
                            .resizable()
                            .scaledToFill()
                            .padding(EdgeInsets(top: 10, leading: 0, bottom: 0, trailing: 0))
                            .frame(width: 70.0, height: 70.0)
                            .clipShape(Circle())
                        Text(singleListing.name + ", " + singleListing.age)
                            .font(.title2)
                            .fontWeight(.semibold)
                            .padding(.vertical, 5.0)
                        Text(singleListing.textMain)
                            .font(.callout)
                            .multilineTextAlignment(.leading)
                            .allowsTightening(true)
                            .minimumScaleFactor(0.75)
                    } .padding(.bottom, 50)
                    .padding(.horizontal, 30)
                }
                .background(Color(.white))
                .cornerRadius(5)
                .shadow(color: Color("Shadow"), radius: 5)

                Text("Already interested")
                    .font(.headline)
                    .fontWeight(.medium)
                    .padding(.vertical, 15.0)
                
                HStack{
                    ForEach(singleListing.interested, id:\.self, content: { person in // get interested people
                        Image(person)
                            .resizable()
                            .scaledToFill()
                            .padding(EdgeInsets(top: 0, leading: 0, bottom: 0, trailing: 0))
                            .frame(width: 49.0, height: 49.0)
                            .clipShape(Circle())
                    })

                }
                Button(action: {
                }) {
                    Text("Show interest")
                        .foregroundColor(Color("GrayPrimaryVariant"))
                        .font(.headline)
                        .padding(.horizontal,110)
                        .padding(.vertical, 15)
                        .background(Color("Primary"))
                        .cornerRadius(25)
                    
                }.padding(.vertical,20)
                
                VStack(alignment: .leading){
                    Text("Location of this post")
                        .font(.headline)
                        .fontWeight(.medium)
                        .padding(.bottom, 5.0)
                    
                    Text(singleListing.location)
                        .font(.callout)
                    
                }.padding(.bottom, 15)

                Text("Shoot styles for this post")
                    .font(.headline)
                    .fontWeight(.medium)
                    .padding(.bottom, 7.0)
                
                LazyVGrid(columns:columns,alignment: .leading, spacing: 10, content: {
                    ForEach(singleListing.shootstyles, id:\.self, content: { style in
                        HStack{
                            Text(style)
                                .font(.footnote)
                                .foregroundColor(.white)
                                .fontWeight(.regular)
                            Image("yes")
                        }.padding(.vertical, 7)
                        .padding(.horizontal, 10)
                        .background(Color("Primary"))
                        .cornerRadius(15)
          
                    })
                    
                })
                .padding(.horizontal, -5)

                VStack(alignment: .leading){
                    Text("Requirements")
                        .font(.headline)
                        .fontWeight(.medium)
                    VStack{
                        HStack{
                            Text("Gender:")
                                .fontWeight(.medium)
                            Text(singleListing.gender)
                            Spacer()
                        }
                        .padding(.bottom,3)
                        HStack{
                            Text("Experience level:")
                                .fontWeight(.medium)
                            Text(singleListing.experience)
                            Spacer()
                        }
                    }.font(.callout)
                    .foregroundColor(Color("PrimaryDark"))
                    .padding(.vertical, 16)
                    
                }.padding(.top, 15)

            }.padding(16)
            .foregroundColor(Color("PrimaryDark"))
            
        }
        .background(Color("Background"))
        .navigationBarColor(backgroundColor:(UIColor(Color(.white))),
                            tintColor: (UIColor(Color("PrimaryDark"))))
        // navigation bar colour using UIKit - see navigation view
        .navigationBarTitle(Text("Listings"),displayMode: .inline) //navigation bar
 
    }
}
