//
//  DiscoverView.swift
//  RAW 3
//
//  Created by Donata Lesiak on 28/03/2021.
//

import SwiftUI

struct DiscoverView: View {
    
    @State var x : CGFloat = 0
    @State var count : CGFloat = 0
    @State var screen = UIScreen.main.bounds.width-30
    @State var op: CGFloat = 0
    
    //  Users data
    
    @State var data = [
        Card(id:0, image:"sarah", avatar:"sarah-avatar", name:"Sarah", age:"23", location:"Bristol, England", distance: "2 kilometers away", about: "I'm a model from Bristol, who wants to gain more experience and enchance portfolio. I travel all over the world for shoots and I am happy to shoot from most locations. I provide all my own lingerie, clothing, accessories and can do my hair and make up to a good standard. \n\nI bring a lot of creativity and ideas to ensure you get the best images possible!", experience: "Proficient",  show:false, appearance: ["Brown","Dark brown", "Armpit length","White","Tanned","None"], sizes:["-","175cm","-","S, 8","-"], measurements:["85cm - 95cm","60cm - 65cm","75cm - 80cm"],portfolio: ["sarah-avatar", "sarah2", "sarah", "sarah3", "sarah1", "sarah4", "sarah5", "sarah7"], shootstyles1:["Alternative", "Beauty", "Commercial","Dance","Fashion","Fitness","Glamour","Lifestyle","Portrait","Promotional","Wedding"], shootstyles2: ["Lingerie","Swimwear"], shootstyles3:["Adult","Body Paint","Bondage","Cosplay","Erotic","Fetish","Nude","Pinup","Sheer","Topless"], reviews:[Review(id:0, avatar:"emily", name:"Emily", age:"25",state:"Reccomended",date:"03/01/2021",text: "I had the pleasure to work with Sarah for the first time during my tour in Bristol, and it was a great experience. She is very professional and her work is absolutely amazing!"),Review(id:1, avatar:"john-avatar", name:"John", age:"28",state:"Reccomended",date:"20/11/2020",text: "Fun, professional, creative, she was fantastic 100% recommended"),Review(id:2, avatar:"lisa-avatar", name:"Lisa", age:"37",state:"Reccomended",date:"10/07/2020",text: "She is a very friendly and charming model and she knows how to pose for a variety of moods and expressions. Sarah is fun to work with and highly recommended.")]),
        Card(id:1, image:"olivia", avatar:"olivia", name:"Olivia", age:"18", location:"Bristol, England", distance: "2 kilometers away", about: "Hi, I'm Olivia. Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Vel turpis nunc eget lorem dolor. Sed vulputate mi sit amet mauris. Suspendisse potenti nullam ac tortor vitae purus faucibus ornare suspendisse. Placerat orci nulla pellentesque dignissim.", experience: "Beginner", show:false, appearance: ["Blue","Blonde", "Armpit length","White","Pale White","None"], sizes:["60kg","163cm","5, 5.5","S, 8","-"], measurements:["85cm - 95cm","75cm - 80cm","75cm - 80cm"], portfolio: [ "olivia"], shootstyles1:["Alternative", "Beauty", "Fashion","Fitness","Glamour","Lifestyle","Portrait"], shootstyles2: ["Adult","Promotional","Sheer","Topless"], shootstyles3:["Body Paint","Bondage","Cosplay","Erotic","Fetish","Nude","Pinup"], reviews:[Review(id:0, avatar:"sofia-avatar", name:"Sofia", age:"19",state:"Reccomended",date:"03/01/2021",text: "I had the pleasure to work with Olivia for the first time during my tour in Bristol, and it was a great experience!"),Review(id:1, avatar:"malcolm-avatar",name:"Malcolm", age:"18",state:"Reccomended",date:"13/11/2020",text: "Working with Olivia was grest! Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Vel turpis nunc eget lorem dolor. Sed vulputate mi sit amet mauris.")]),
        Card(id:2, image:"jason", avatar:"jason", name:"Jason",age:"24", location:"Bristol, England", distance: "3 kilometers away", about: "Hello,I'm Jason. Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Vel turpis nunc eget lorem dolor. Sed vulputate mi sit amet mauris. Suspendisse potenti nullam ac tortor vitae purus faucibus ornare suspendisse. Placerat orci nulla pellentesque dignissim.", experience: "Competent", show:false, appearance: ["Brown","Dark brown", "Short","African","Black","None"], sizes:["97kg","185cm","-","L","-"], measurements:["85cm-95cm","60cm-65cm","75cm-80cm"], portfolio: [ "jason"], shootstyles1:["Alternative", "Beauty", "Fashion","Fitness","Lifestyle"], shootstyles2: ["Body paint", "Promotional", "Topless", "Wedding"], shootstyles3:["Adult","Erotic", "Lingerie", "Fetish", "Nude"], reviews:[Review(id:0, avatar:"mariusz-avatar", name:"Mariusz", age:"32",state:"Reccomended",date:"03/01/2021",text: "It was great working with Jason! Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Vel turpis nunc eget lorem dolor. Sed vulputate mi sit amet mauris. "),Review(id:1, avatar:"malcolm-avatar",name:"Malcolm", age:"18",state:"Reccomended",date:"13/11/2020",text: "Working with Jason was amazing! Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Vel turpis nunc eget lorem dolor. Sed vulputate mi sit amet mauris.")]),
        Card(id:3, image:"matt", avatar:"matt", name:"Matt", age:"22", location:"Bristol, England", distance: "4 kilometers away", about: "Welcome, I'm Matt. Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Vel turpis nunc eget lorem dolor. Sed vulputate mi sit amet mauris. Suspendisse potenti nullam ac tortor vitae purus faucibus ornare suspendisse. Placerat orci nulla pellentesque dignissim.", experience: "Intermediate", show:false, appearance: ["Brown","Dark brown", "Short","Persian","Mixed race","None"], sizes:["76kg","182cm","-","M,12","-"], measurements:["95cm-105cm","60cm-65cm","95cm-105cm"], portfolio: [ "matt"],shootstyles1:["Alternative", "Beauty", "Glamour","Lifestyle","Portrait"], shootstyles2: ["Commercial","Dance"], shootstyles3:["Adult", "Cosplay","Erotic","Fetish"],reviews:[Review(id:0, avatar:"malcolm-avatar",name:"Malcolm", age:"18",state:"Reccomended",date:"03/01/2021",text: "Working with Matt was great! Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Vel turpis nunc eget lorem dolor. Sed vulputate mi sit amet mauris."),Review(id:1, avatar:"lisa-avatar",name:"Lisa", age:"37",state:"Reccomended",date:"13/11/2020",text: "Working with Matt was super adventure! Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. "),Review(id:2, avatar:"john-avatar",name:"John", age:"28",state:"Reccomended",date:"09/06/2020",text: "Really reccomend working with Matt! Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Vel turpis nunc eget lorem dolor. Sed vulputate mi sit amet mauris.")])
    ]
    
    
    var body: some View {
        
        NavigationView{
            ZStack{
                Color("Background").edgesIgnoringSafeArea(.all)
                VStack(alignment: .center){
                    HStack(spacing: 15){
                        ForEach(data){i in // Loop through all user data and create card views as per CardView struct
                            CardView(cardData: i) // Display user in the card as per parameter
                                .offset(x: self.x)
                                .highPriorityGesture(DragGesture() // adding drag geasture with offsets, spring animation and limitations (drag until specific point and let system to finish the transation if needed)
                                                        //Carousel list tutorial - swipe on drag gesture
                                                        //Venkatshes, n.d https://kavsoft.dev/Swift/Carousel%20List/
                                                        .onChanged({ (value) in
                                                            if value.translation.width > 0{
                                                                self.x = value.location.x
                                                            }
                                                            else{
                                                                self.x = value.location.x - self.screen
                                                            }
                                                        })
                                                        .onEnded({ (value) in
                                                            if value.translation.width > 0{
                                                                if value.translation.width > ((self.screen - 80) / 2) && Int(self.count) != 0{
                                                                    self.count -= 1
                                                                    self.updateHeight(value: Int(self.count))
                                                                    self.x = -((self.screen + 15) * self.count)
                                                                }
                                                                else{
                                                                    self.x = -((self.screen + 15) * self.count)
                                                                }
                                                            }
                                                            else{
                                                                if -value.translation.width > ((self.screen - 80) / 2) && Int(self.count) !=  (self.data.count - 1){
                                                                    
                                                                    self.count += 1
                                                                    self.updateHeight(value: Int(self.count))
                                                                    self.x = -((self.screen + 15) * self.count)
                                                                }
                                                                else{
                                                                    
                                                                    self.x = -((self.screen + 15) * self.count)
                                                                }
                                                            }
                                                        })
                                )
                        }
                    }
                    .frame(width: UIScreen.main.bounds.width)
                    .offset(x: self.op)
                }
                .animation(.spring())
                .onAppear {
                    self.op = ((self.screen + 15) * CGFloat(self.data.count / 2)) - (self.data.count % 2 == 0 ? ((self.screen + 15) / 2) : 0)
                    self.data[0].show = true
                }
                .navigationBarTitle(Text(""), displayMode: .inline) //navigation bar, inline to show logo ther than section name
                .navigationBarItems(leading:
                                        HStack {
                                            Button(action: {}) {
                                                Image("logo")
                                            }
                                        }, trailing:
                                            HStack {
                                                Button(action: {}) {
                                                    Image("notification")
                                                        .font(.largeTitle)
                                                }
                                            })
            }
        }
    }
    
    func updateHeight(value : Int){
        for i in 0..<data.count{
            data[i].show = false
        }
        data[value].show = true
    }
}


struct DiscoverView_Previews: PreviewProvider {
    static var previews: some View {
        DiscoverView()
    }
}

struct CardView:View{  //create the card component
    
    var cardData: Card // allows to use data from the data array
    var titlesAppearance = ["Eyes","Hair colour", "Hair lenght", "Ethnicity","Skin colour","Tattoos"]
    var titlesSizes = ["Weight","Height", "Shoe size", "Dress size","Cup size"]
    var titlesMeasurements = ["Hips","Waist", "Bust size"]
    
    @State private var showingSheet = false // modal sheet set state
    @State private var isLiked = false // like heart buton set state
    
    @State private var selectedStateIndex1 = 0 // set state for apperance, sizes and measurements picker
    @State private var selectedStateIndex2 = 0 // set state for shootstyles, images, reviews picker
    
    var body: some View{
        VStack{ // The visible card
            ZStack{
                Image(cardData.image)
                    .resizable()
                    .scaledToFit()
                    .cornerRadius(20)
                HStack{
                    Button(action: {
                        showingSheet.toggle()
                        //set the bottom component (image, name, location etc) as button that triggers the modal view with profile portfolio (showing modal sheet over)
                        //Simple Swift Guide (2019) https://www.simpleswiftguide.com/how-to-present-sheet-modally-in-swiftui/
                    }){
                        Image(cardData.avatar)
                            .resizable()
                            .scaledToFill()
                            .padding(EdgeInsets(top: 10, leading: 0, bottom: 0, trailing: 0))
                            .frame(width: 55.0, height: 55.0)
                            .clipShape(Circle())
                            .padding(.trailing, 10)
                        VStack(alignment: .leading){
                            Text(cardData.name + ", " + cardData.age)
                                .font(.title2)
                                .fontWeight(.semibold)
                                .foregroundColor(Color("PrimaryDark"))
                                .padding(.bottom, 3.0)
                            Text(cardData.distance)
                                .font(.callout)
                                .foregroundColor(Color("Secondary"))
                        }.padding(.trailing, 30)
                        
                        Button(action: {
                            self.isLiked.toggle() // Like button toggle
                            //Patron (2020) https://www.youtube.com/watch?v=aJ3DXOe_skU
                        }) {
                            Image(isLiked ? "unlike" : "like") // swap between heart icons
                        }  .padding(.leading, 40.0)
                    }
                    
                    .sheet(isPresented: $showingSheet) { // modal sheet view content
                        
                        ScrollView{
                            VStack{
                                HStack{
                                    Image(cardData.avatar)
                                        .resizable()
                                        .scaledToFill()
                                        .padding(EdgeInsets(top: 10, leading: 0, bottom: 0, trailing: 0))
                                        .frame(width: 55.0, height: 55.0)
                                        .clipShape(Circle())
                                        .padding(.trailing, 10)
                                    VStack(alignment: .leading){
                                        Text(cardData.name + ", " + cardData.age)
                                            .font(.title2)
                                            .fontWeight(.semibold)
                                            .foregroundColor(Color("PrimaryDark"))
                                            .padding(.bottom, 3.0)
                                        
                                        Text(cardData.distance)
                                            .font(.callout)
                                            .foregroundColor(Color("Secondary"))
                                    }.padding(.trailing, 30)
                                    
                                    Button(action: {
                                        self.isLiked.toggle()
                                    }) {
                                        Image(isLiked ? "unlike" : "like")
                                    }  .padding(.leading, 40.0)
                                } .padding(.vertical, 20)
                                
                                VStack(alignment: .leading){
                                    Text("About")
                                        .font(.headline)
                                        .fontWeight(.medium)
                                        .foregroundColor(Color("PrimaryDark"))
                                        .padding(.bottom, 3.0)
                                    Text(cardData.about)
                                        .font(.callout)
                                        .foregroundColor(Color("PrimaryDark"))
                                        .multilineTextAlignment(.leading)
                                        .allowsTightening(true)
                                        .minimumScaleFactor(0.75)
                                        .padding(.bottom, 3.0)
                                    
                                    HStack{
                                        Text("Lives in")
                                            .font(.headline)
                                            .fontWeight(.medium)
                                            .foregroundColor(Color("PrimaryDark"))
                                            .padding(.bottom, 3.0)
                                        Text(cardData.location)
                                            .font(.callout)
                                            .foregroundColor(Color("PrimaryDark"))
                                    }
                                    .padding(.bottom, 3.0)
                                    
                                    HStack{
                                        Text("Experience")
                                            .font(.headline)
                                            .fontWeight(.medium)
                                            .foregroundColor(Color("PrimaryDark"))
                                            .padding(.bottom, 3.0)
                                        Text(cardData.experience)
                                            .font(.callout)
                                            .foregroundColor(Color("PrimaryDark"))
                                    }
                                    .padding(.bottom, 10.0)
                                }
                                
                                Picker("Picker 1", selection: $selectedStateIndex1, content: { //selection picker 1
                                    Text("Appearance")
                                        .foregroundColor(Color("PrimaryDark"))
                                        .fontWeight(.medium).tag(0)
                                    
                                    Text("Sizes").foregroundColor(Color("PrimaryDark"))
                                        .fontWeight(.medium).tag(1)
                                    
                                    Text("Measurements").foregroundColor(Color("PrimaryDark"))
                                        .fontWeight(.medium).tag(2)
                                    
                                })
                                .pickerStyle(SegmentedPickerStyle()) // set style for segmented picker
                                
                                switch selectedStateIndex1{ // case switch statement to swap between picker sections
                                
                                case 0: //apperance
                                    VStack (alignment: .leading){
                                        ForEach(titlesAppearance.indices){ i in //loop through titles indices returning index
                                            HStack{
                                                Text(titlesAppearance[i] + ":") // display title and appearance data accordingly
                                                    .fontWeight(.medium)
                                                Text(cardData.appearance[i])
                                                Spacer()
                                            }.padding(.bottom, 5)
                                        }
                                    }
                                    .font(.callout)
                                    .foregroundColor(Color("PrimaryDark"))
                                    .padding(.vertical, 16)
                                    
                                case 1: //sizes
                                    VStack (alignment: .leading){
                                        
                                        ForEach(titlesSizes.indices){ i in
                                            HStack{
                                                Text(titlesSizes[i] + ":")
                                                    .fontWeight(.medium)
                                                Text(cardData.sizes[i])
                                                Spacer()
                                            }.padding(.bottom, 5)
                                        }
                                    }
                                    .font(.callout)
                                    .foregroundColor(Color("PrimaryDark"))
                                    .padding(.vertical, 16)
                                    
                                default: //measurements
                                    
                                    VStack (alignment: .leading){
                                        
                                        ForEach(titlesMeasurements.indices){ i in
                                            HStack{
                                                Text(titlesMeasurements[i] + ":")
                                                    .fontWeight(.medium)
                                                Text(cardData.measurements[i])
                                                Spacer()
                                            }.padding(.bottom, 5)
                                        }
                                    }
                                    .font(.callout)
                                    .foregroundColor(Color("PrimaryDark"))
                                    .padding(.vertical, 16)
                                }
                                
                                Picker("Picker 2", selection: $selectedStateIndex2, content: { //selection picker 2
                                    Text("Shoot styles")
                                        .foregroundColor(Color("PrimaryDark"))
                                        .fontWeight(.medium).tag(0)
                                    
                                    Text("Portfolio").foregroundColor(Color("PrimaryDark"))
                                        .fontWeight(.medium).tag(1)
                                    
                                    Text("Reviews").foregroundColor(Color("PrimaryDark"))
                                        .fontWeight(.medium).tag(2)
                                    
                                })
                                .pickerStyle(SegmentedPickerStyle())
                                
                                // grid styles for grid display
                                let columns = [
                                    GridItem(.flexible()),
                                    GridItem(.flexible()),
                                    GridItem(.flexible()),
                                ]
                                let columns2 = [
                                    GridItem(.adaptive(minimum: 100, maximum: 160),spacing: 0)
                                ]
                                
                                switch selectedStateIndex2{
                                case 0: //shoot styles
                                    VStack(alignment: .leading){
                                        // yes shootstyles
                                        LazyVGrid(columns:columns2,alignment: .leading, spacing: 10, content: {
                                            ForEach(cardData.shootstyles1, id:\.self, content: { style1 in
                                                HStack{
                                                    Text(style1)
                                                        .font(.footnote)
                                                        .foregroundColor(.white)
                                                        .fontWeight(.regular)
                                                    Image("yes")
                                                }.padding(.vertical, 7)
                                                .padding(.horizontal, 10)
                                                .background(Color("Primary"))
                                                .cornerRadius(15)
                                            })
                                            Spacer()
                                            
                                        }).padding(.top, 20)
                                        .padding(.horizontal, -5)
                                        // maybe shootstyles
                                        LazyVGrid(columns: columns2,alignment: .leading, spacing: 10, content: {
                                            ForEach(cardData.shootstyles2, id:\.self, content: { style2 in
                                                HStack{
                                                    Text(style2)
                                                        .font(.footnote)
                                                        .foregroundColor(Color("PrimaryDark"))
                                                        .fontWeight(.regular)
                                                    Image("maybe")
                                                }.padding(.vertical, 7)
                                                .padding(.horizontal, 10)
                                                .background(Color("PrimaryVariant"))
                                                .cornerRadius(15)
                                                
                                            })
                                            Spacer()
                                            
                                        }).padding(.vertical, 10)
                                        .padding(.horizontal, -5)
                                        
                                        // no shootstyles
                                        LazyVGrid(columns: columns2,alignment: .leading, spacing: 10, content: {
                                            ForEach(cardData.shootstyles3, id:\.self, content: { style3 in
                                                HStack{
                                                    Text(style3)
                                                        .font(.footnote)
                                                        .foregroundColor(Color("PrimaryDark"))
                                                        .fontWeight(.regular)
                                                    Image("no")
                                                }.padding(.vertical, 7)
                                                .padding(.horizontal, 10)
                                                .background(Color("GrayPrimaryVariant"))
                                                .cornerRadius(15)
                                                
                                            })
                                            Spacer()
                                        }).padding(.bottom, 20)
                                        .padding(.horizontal, -5)
                                        
                                    }
                                    
                                case 1: //portfolio images
                                    
                                    LazyVGrid(columns: columns, spacing: 15, content: { // display data in grid
                                        ForEach(cardData.portfolio, id:\.self, content: { image in //loop through images in card portfolio and display in grid
                                            Image(image)
                                                .resizable()
                                                .scaledToFill()
                                                .frame(width: 100.0, height: 140.0)
                                                .cornerRadius(5)
                                        })
                                    }).padding(.vertical, 16)
                                    
                                    
                                default: //reviews
                                    VStack{
                                        ForEach(cardData.reviews, id:\.self, content: { review in
                                            VStack(alignment: .leading){
                                                HStack(alignment: .center){
                                                    Image(review.avatar)
                                                        .resizable()
                                                        .scaledToFill()
                                                        .padding(EdgeInsets(top: 0, leading: 0, bottom: 0, trailing: 0))
                                                        .frame(width: 55.0, height: 55.0)
                                                        .clipShape(Circle())
                                                    
                                                    VStack(alignment: .leading){
                                                        Text(review.name + ", " + review.age)
                                                            .font(.callout)
                                                            .fontWeight(.medium)
                                                            .foregroundColor(Color("PrimaryDark"))
                                                            .padding(.bottom, 1.0)
                                                        
                                                        Text(review.state + " - " + review.date)
                                                            .font(.caption2)
                                                            .foregroundColor(Color("Secondary"))
                                                            .padding(.bottom, 1.0)
                                                    }
                                                }
                                                
                                                Text(review.text)
                                                    .font(.footnote)
                                                    .foregroundColor(Color("PrimaryDark"))
                                                //                                                    .allowsTightening(true)
                                                //                                                    .minimumScaleFactor(0.75)
                                            }
                                            
                                            .padding()
                                            .background(Color("GraySecondary"))
                                            .cornerRadius(5)
                                            .shadow(color: Color("ShadowDark"), radius: 5)
                                            
                                        })
                                        Spacer()
                                    }
                                    .padding(.top, 20)
                                    
                                }
                            }.padding(.horizontal, 16)
                            
                        }.padding(.top, 40)
                    }
                }
                .frame(width: cardData.show ? UIScreen.main.bounds.width - 30 : 315, height: cardData.show ? 105 : 95 ) //resizing effect on drag
                .background(Color("Background"))
                .cornerRadius(30)
                .padding(.top, 530.0)
            }
        }.frame(width: UIScreen.main.bounds.width - 30, height: cardData.show ? 625 : 500) //resizing effect on drag
        .padding(.top, -40.0)
        
    }
}

//card struct (defining the object)
struct Card: Identifiable{
    var id: Int
    var image, avatar, name, age, location, distance, about, experience: String
    var show: Bool
    var appearance, sizes, measurements:[String]
    var portfolio:[String]
    var shootstyles1:[String]
    var shootstyles2:[String]
    var shootstyles3:[String]
    var reviews:[Review]
}

struct Review: Hashable{
    var id: Int
    var avatar, name, age, state, date, text: String
}


