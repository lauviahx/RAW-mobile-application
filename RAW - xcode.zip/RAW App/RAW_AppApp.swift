//
//  RAW_AppApp.swift
//  RAW App
//
//  Created by Donata Lesiak on 31/03/2021.
//

import SwiftUI

@main
struct RAW_AppApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
