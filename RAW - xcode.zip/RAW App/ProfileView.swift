//
//  ProfileView.swift
//  RAW
//
//  Created by Donata Lesiak on 20/03/2021.
//

import SwiftUI

struct ProfileView: View {
    
    @State var accountData = [
        Account(id: 0, avatar:"john-avatar", name:"John", age:"28", location:"Bristol, England", about: "I'm a Bristol based photographer with over 5 years experience. Photography is my passion, a pass to the world of art and expresing my ideas. Love working with models who trust my vision.", experience: "Proficient",portfolio: ["johnportfolio1", "johnportfolio2", "johnportfolio3", "johnportfolio4", "johnportfolio5", "johnportfolio6", "johnportfolio7", "johnportfolio8","johnportfolio9"], shootstyles1:["Alternative", "Beauty", "Commercial","Dance","Fashion","Fitness","Glamour","Lifestyle","Portrait","Promotional","Wedding"], shootstyles2: ["Lingerie","Swimwear"], shootstyles3:["Adult","Body Paint","Bondage","Cosplay","Erotic","Fetish","Nude","Pinup","Sheer","Topless"], reviews:[ReviewPersonal(id:0, avatar:"johnportfolio2", name:"Emma", age:"20",state:"Reccomended",date:"03/01/2021",text: "Funny, imaginative and incredibly good fun to work with. I hope to have the pleasure of working with him regularly in the future. Amazing shoot outcomes, truly in love with what we created!"),ReviewPersonal(id:2, avatar:"johnportfolio3", name:"Jessica", age:"32",state:"Reccomended",date:"10/07/2020",text: "I would highly recommend working with John, I love the photo I have seen already and can't wait to see more. The time just flew by and I look forward to working together again sometime.")]),
    ]
    
    @State private var selectedStateProfile = 0 // picker profile
    
    var body: some View {
        
        NavigationView{
            ScrollView{
                VStack{
                    ZStack{
                        Image(accountData[0].avatar)
                            .resizable()
                            .scaledToFill()
                            .padding(EdgeInsets(top: 0, leading: 0, bottom: 0, trailing: 0))
                            .frame(width: 140.0, height: 140.0)
                            .clipShape(Circle())
                            .padding(.trailing, 10)
                        
                        Button(action: {
                        }) {
                            Image("editButton")
                                .padding(.top, 100)
                                .padding(.leading, 100)
                        }
                    }
                    
                    Text(accountData[0].name + ", " + accountData[0].age)
                        .font(.title2)
                        .fontWeight(.semibold)
                        .padding(.vertical, 5.0)
                    
                    VStack(alignment: .leading){
                        Text("About")
                            .font(.headline)
                            .fontWeight(.medium)
                            .foregroundColor(Color("PrimaryDark"))
                            .padding(.bottom, 3.0)
                        Text(accountData[0].about)
                            .font(.callout)
                            .foregroundColor(Color("PrimaryDark"))
                            .multilineTextAlignment(.leading)
                            .allowsTightening(true)
                            .minimumScaleFactor(0.75)
                            .padding(.bottom, 3.0)
                        HStack{
                            Text("Lives in")
                                .font(.headline)
                                .fontWeight(.medium)
                                .foregroundColor(Color("PrimaryDark"))
                                .padding(.bottom, 3.0)
                            Text(accountData[0].location)
                                .font(.callout)
                                .foregroundColor(Color("PrimaryDark"))
                            
                        }
                        .padding(.bottom, 3.0)
                        
                        HStack{
                            Text("Experience")
                                .font(.headline)
                                .fontWeight(.medium)
                                .foregroundColor(Color("PrimaryDark"))
                                .padding(.bottom, 3.0)
                            Text(accountData[0].experience)
                                .font(.callout)
                                .foregroundColor(Color("PrimaryDark"))
                            
                        }
                        .padding(.bottom, 10.0)
                        
                        Picker("Picker Profile", selection: $selectedStateProfile, content: { //selection picker profile
                            Text("Shoot styles")
                                .foregroundColor(Color("PrimaryDark"))
                                .fontWeight(.medium).tag(0)
                            
                            Text("Portfolio").foregroundColor(Color("PrimaryDark"))
                                .fontWeight(.medium).tag(1)
                            
                            Text("Reviews").foregroundColor(Color("PrimaryDark"))
                                .fontWeight(.medium).tag(2)
                            
                        })
                        .pickerStyle(SegmentedPickerStyle())
                        
                        let columnsProfile = [
                            GridItem(.adaptive(minimum: 100, maximum: 160),spacing: 0)
                        ]
                        
                        switch selectedStateProfile{
                        case 0: //shoot styles
                            
                            VStack(alignment: .leading){
                                LazyVGrid(columns:columnsProfile,alignment: .leading, spacing: 10, content: {
                                    ForEach(accountData[0].shootstyles1, id:\.self, content: { style1 in
                                        HStack{
                                            Text(style1)
                                                .font(.footnote)
                                                .foregroundColor(.white)
                                                .fontWeight(.regular)
                                            Image("yes")
                                        }.padding(.vertical, 7)
                                        .padding(.horizontal, 10)
                                        .background(Color("Primary"))
                                        .cornerRadius(15)
                                    })
                                    Spacer()
                                    
                                }).padding(.top, 20)
                                .padding(.horizontal, -5)
                                
                                LazyVGrid(columns: columnsProfile,alignment: .leading, spacing: 10, content: {
                                    ForEach(accountData[0].shootstyles2, id:\.self, content: { style2 in
                                        HStack{
                                            Text(style2)
                                                .font(.footnote)
                                                .foregroundColor(Color("PrimaryDark"))
                                                .fontWeight(.regular)
                                            Image("maybe")
                                        }.padding(.vertical, 7)
                                        .padding(.horizontal, 10)
                                        .background(Color("PrimaryVariant"))
                                        .cornerRadius(15)
                                        
                                    })
                                    Spacer()
                                    
                                }).padding(.vertical, 10)
                                .padding(.horizontal, -5)
                                
                                LazyVGrid(columns: columnsProfile,alignment: .leading, spacing: 10, content: {
                                    
                                    ForEach(accountData[0].shootstyles3, id:\.self, content: { style3 in
                                        HStack{
                                            Text(style3)
                                                .font(.footnote)
                                                .foregroundColor(Color("PrimaryDark"))
                                                .fontWeight(.regular)
                                            Image("no")
                                        }.padding(.vertical, 7)
                                        .padding(.horizontal, 10)
                                        .background(Color("GrayPrimaryVariant"))
                                        .cornerRadius(15)
                                        
                                    })
                                    Spacer()
                                }).padding(.bottom, 20)
                                .padding(.horizontal, -5)
                                
                            }
                            
                        case 1: //portfolio images
                            
                            LazyVGrid(columns: [
                                GridItem(.flexible()),
                                GridItem(.flexible()),
                                GridItem(.flexible()),
                            ], spacing: 15, content: {
                                
                                ForEach(accountData[0].portfolio, id:\.self, content: { image in
                                    Image(image)
                                        .resizable()
                                        .scaledToFill()
                                        .frame(width: 100.0, height: 140.0)
                                        .cornerRadius(5)
                                })
                                
                            }).padding(.vertical, 20)
                            
                        default: //reviews
                            VStack(){
                                ForEach(accountData[0].reviews, id:\.self, content: { review in
                                    VStack(alignment: .trailing){
                                        VStack(alignment: .leading){
                                            HStack(alignment: .center){
                                                Image(review.avatar)
                                                    .resizable()
                                                    .scaledToFill()
                                                    .padding(EdgeInsets(top: 10, leading: 0, bottom: 0, trailing: 0))
                                                    .frame(width: 55.0, height: 55.0)
                                                    .clipShape(Circle())
                                                
                                                VStack(alignment: .leading){
                                                    Text(review.name + ", " + review.age)
                                                        .font(.callout)
                                                        .fontWeight(.medium)
                                                        .padding(.bottom, 1.0)
                                                    
                                                    Text(review.state + " - " + review.date)
                                                        .font(.caption2)
                                                        .foregroundColor(Color("Secondary"))
                                                        .padding(.bottom, 1.0)
                                                }
                                            }
                                            
                                            Text(review.text)
                                                .font(.footnote)
                                        }
                                        
                                        Button(action: {}) {
                                            Text("Reply or report")
                                                .font(.system(size:12))
                                                .foregroundColor(Color("GraySecondary400"))
                                                .padding(.top, 5)
                                        }
                                    }
                                    
                                    .padding()
                                    .background(Color("GraySecondary"))
                                    .foregroundColor(Color("PrimaryDark"))
                                    .cornerRadius(5)
                                    .shadow(color: Color("ShadowDark"), radius: 5)
                                    
                                    
                                })
                                
                                
                            } .padding(.top, 20)
                            
                        }
                        
                    }
                    
                }.padding(16)
                .foregroundColor(Color("PrimaryDark"))
                .frame(maxWidth: .infinity)
                
            }.background(Color("Background"))
            .navigationBarColor(backgroundColor:(UIColor(Color(.white))), tintColor: (UIColor(Color("PrimaryDark")))) // navigation bar colour using UIKit - see navigation view
            .navigationBarTitle(Text("Profile")) //navigation bar
            .navigationBarItems( trailing:
                                    HStack {
                                        Button(action: {}) {
                                            Image("shoots-reviews")
                                        }
                                        Button(action: {}) {
                                            Image("calendar")
                                        }.padding(10)
                                        Button(action: {}) {
                                            Image("settings")
                                        }
                                    })
        }
    }
}

struct ProfileView_Previews: PreviewProvider {
    static var previews: some View {
        ProfileView()
    }
}

//account struct (defining the object)
struct Account: Identifiable{
    var id:Int
    var avatar, name, age, location, about, experience: String
    var portfolio:[String]
    var shootstyles1:[String]
    var shootstyles2:[String]
    var shootstyles3:[String]
    var reviews: [ReviewPersonal]
}

struct ReviewPersonal: Hashable{
    var id: Int
    var avatar, name, age, state, date, text: String
}

